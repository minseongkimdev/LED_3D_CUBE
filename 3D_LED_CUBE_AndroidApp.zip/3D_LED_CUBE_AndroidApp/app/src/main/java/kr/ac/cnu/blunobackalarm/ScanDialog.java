package kr.ac.cnu.blunobackalarm;

import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.RecyclerView;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ScanDialog extends Dialog {
    @BindView(R.id.deviceList_recyclerView)
    RecyclerView recyclerView;

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner mBLEScanner;

    private boolean mScanning;
    private Handler mHandler;

    private static final long SCAN_PERIOD = 5000;

    private Context context;
    private DeviceListAdapter adapter;

    public String name;
    public String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 다이얼로그 외부 화면 흐리게 표현
        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.dialog_devicelist);
        ButterKnife.bind(this);

        adapter = new DeviceListAdapter(this);
        recyclerView.setAdapter(adapter);

        scanLeDevice(true);
    }

    public ScanDialog(Context context, BluetoothAdapter mBluetoothAdapter, BluetoothLeScanner mBLEScanner) {
        super(context, android.R.style.Theme_Translucent_NoTitleBar);
        this.context = context;
        this.mBluetoothAdapter = mBluetoothAdapter;
        this.mBLEScanner = mBLEScanner;
    }

    @OnClick(R.id.deviceList_close_button)
    void onClickClose() {
        scanLeDevice(false);
        this.dismiss();
    }

    public void startConntect(String name, String address) {
        this.name = name;
        this.address = address;
        this.dismiss();
    }

    private void scanLeDevice(final boolean enable) {
        mHandler = new Handler();

        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    mBLEScanner.stopScan(mScanCallback);
                    invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBLEScanner.startScan(mScanCallback);
        } else {
            mScanning = false;
            mBLEScanner.stopScan(mScanCallback);
        }
        invalidateOptionsMenu();
    }

    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            processResult(result);
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult result : results) {
                processResult(result);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Toast.makeText(context, "Scan Failed", Toast.LENGTH_SHORT).show();
        }

        private void processResult(final ScanResult result) {
            ((MainActivity)context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    adapter.addDevice(result.getDevice());
                    adapter.notifyDataSetChanged();
                }
            });
        }
    };
}
