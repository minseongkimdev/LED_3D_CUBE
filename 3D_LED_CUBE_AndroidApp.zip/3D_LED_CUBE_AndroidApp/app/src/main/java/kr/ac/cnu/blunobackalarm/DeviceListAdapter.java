package kr.ac.cnu.blunobackalarm;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DeviceListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>  {
    private List<BluetoothDevice> list = new ArrayList<>();
    private ScanDialog context;

    public DeviceListAdapter(ScanDialog context){
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_devicelist, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int i) {
        ViewHolder viewHolder = (ViewHolder) holder;

        viewHolder.name.setText(list.get(i).getName());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void clear() {
        list.clear();
    }

    public void addDevice(BluetoothDevice device) {
        if (device.getName() != null && !list.contains(device)) {
            Log.d("name", device.getName());
            list.add(device);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.itemDeviceList_name_textView)
        TextView name;

        public ViewHolder(View view){
            super(view);
            ButterKnife.bind(this, view);
        }

        @OnClick(R.id.itemDeviceList_name_textView)
        void onClick() {
            context.startConntect(list.get(getAdapterPosition()).getName(), list.get(getAdapterPosition()).getAddress());
        }
    }
}
