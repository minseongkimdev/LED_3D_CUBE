package kr.ac.cnu.blunobackalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends BlunoLibrary  {
    @BindView(R.id.main_scan_button)
    Button button;
    Vibrator vibrator;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        tv = (TextView)findViewById(R.id.tv);
        onCreateProcess();

        vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
    }

    protected void onResume(){
        super.onResume();
        System.out.println("BlUNOActivity onResume");
        onResumeProcess();														//onResume Process by BlunoLibrary
    }

    @Override
    protected void onPause() {
        super.onPause();
        onPauseProcess();														//onPause Process by BlunoLibrary
    }

    protected void onStop() {
        super.onStop();
        onStopProcess();														//onStop Process by BlunoLibrary
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        onDestroyProcess();														//onDestroy Process by BlunoLibrary
    }

    @OnClick(R.id.main_scan_button)
    void onClickScan() {
        buttonScanOnClickProcess();
    }

    @Override
    public void onConectionStateChange(connectionStateEnum theConnectionState) {
        switch (theConnectionState) {											//Four connection state
            case isConnected:
                button.setText("Connected");
                break;
            case isConnecting:
                button.setText("Connecting");
                break;
            case isToScan:
                button.setText("Scan");
                break;
            case isScanning:
                button.setText("Scanning");
                break;
            case isDisconnecting:
                button.setText("isDisconnecting");
                break;
            default:
                break;
        }
    }

    @Override
    public void onSerialReceived(String string) {
        //string = string.replaceAll("[^0-9]", "");
        /*int value = Integer.parseInt(string);
        if (value / 10 > 1) {
            value /= 10;
        }*/
        //vibrator.vibrate(100 * value);
        //tv.setText(value)
        //tv.setText("");
       // String text = "@"+string+"\n";
        tv.setText("");
        tv.append(string);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        onActivityResultProcess(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
}
